frontend-nanodegree-arcade-game
===============================
1. use up,down,left, and right keys to move character.
2. successfully make it to water to feed the imaginary fish in the water.
3. do not get hit by bugs while crossing the sidewalk.
4. once you make it to end, or if you get hit by a bug, you will start over.
5. enjoy!

Students should use this rubric: https://www.udacity.com/course/viewer#!/c-ud015/l-3072058665/m-3072588797

for self-checking their submission.

